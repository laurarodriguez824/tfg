<?php
$host = "localhost";
$user = "root";
$pass = "root";     
$db   = "tienda_online";
$port = 8889;       

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>